(() => {
  // ── State ────────────────────────────────────────────────────────────────
  let enabled = false;
  let virtualX = window.innerWidth / 2;
  let virtualY = window.innerHeight / 2;
  let animFrame = null;
  let isSnapping = false;

  // ── Create virtual cursor element ────────────────────────────────────────
  const cursor = document.createElement('div');
  cursor.id = '__cursorsnap_cursor__';
  cursor.innerHTML = `
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M4 2L20 11.5L12.5 13.5L9 21L4 2Z" fill="white" stroke="#1a1a2e" stroke-width="1.5" stroke-linejoin="round"/>
    </svg>
  `;

  Object.assign(cursor.style, {
    position: 'fixed',
    top: '0',
    left: '0',
    width: '24px',
    height: '24px',
    pointerEvents: 'none',
    zIndex: '2147483647',
    transform: `translate(${virtualX}px, ${virtualY}px)`,
    transition: 'none',
    display: 'none',
    filter: 'drop-shadow(0 1px 3px rgba(0,0,0,0.5))',
    willChange: 'transform',
  });

  // Snap ring — shows on click
  const ring = document.createElement('div');
  ring.id = '__cursorsnap_ring__';
  Object.assign(ring.style, {
    position: 'fixed',
    top: '0',
    left: '0',
    width: '32px',
    height: '32px',
    border: '2px solid rgba(99,102,241,0.85)',
    borderRadius: '50%',
    pointerEvents: 'none',
    zIndex: '2147483646',
    transform: `translate(${window.innerWidth / 2 - 16}px, ${window.innerHeight / 2 - 16}px) scale(0)`,
    transition: 'transform 0.35s cubic-bezier(0.34,1.56,0.64,1), opacity 0.35s ease',
    opacity: '0',
    display: 'none',
    willChange: 'transform, opacity',
  });

  // ── Inject style to hide the real cursor ────────────────────────────────
  const style = document.createElement('style');
  style.id = '__cursorsnap_style__';
  style.textContent = `
    .__cursorsnap_active__ *,
    .__cursorsnap_active__ {
      cursor: none !important;
    }
  `;

  // ── Helpers ──────────────────────────────────────────────────────────────
  function attachToDOM() {
    if (!document.body) return;
    if (!document.head.contains(style)) document.head.appendChild(style);
    if (!document.body.contains(cursor)) document.body.appendChild(cursor);
    if (!document.body.contains(ring)) document.body.appendChild(ring);
  }

  function enable() {
    enabled = true;
    attachToDOM();
    document.documentElement.classList.add('__cursorsnap_active__');
    cursor.style.display = 'block';
    ring.style.display = 'block';
    // Start at center
    virtualX = window.innerWidth / 2;
    virtualY = window.innerHeight / 2;
    moveCursorTo(virtualX, virtualY, false);
  }

  function disable() {
    enabled = false;
    document.documentElement.classList.remove('__cursorsnap_active__');
    cursor.style.display = 'none';
    ring.style.display = 'none';
    if (animFrame) cancelAnimationFrame(animFrame);
  }

  // Smoothly animate virtual cursor from current pos to target
  function animateCursor(targetX, targetY, duration = 320) {
    if (animFrame) cancelAnimationFrame(animFrame);
    isSnapping = true;

    const startX = virtualX;
    const startY = virtualY;
    const startTime = performance.now();

    // Ease-out-quart
    function easeOutQuart(t) {
      return 1 - Math.pow(1 - t, 4);
    }

    function step(now) {
      const elapsed = now - startTime;
      const t = Math.min(elapsed / duration, 1);
      const ease = easeOutQuart(t);

      virtualX = startX + (targetX - startX) * ease;
      virtualY = startY + (targetY - startY) * ease;

      cursor.style.transform = `translate(${virtualX}px, ${virtualY}px)`;

      if (t < 1) {
        animFrame = requestAnimationFrame(step);
      } else {
        virtualX = targetX;
        virtualY = targetY;
        isSnapping = false;
      }
    }

    animFrame = requestAnimationFrame(step);
  }

  function moveCursorTo(x, y, animate = false) {
    if (animate) {
      animateCursor(x, y);
    } else {
      virtualX = x;
      virtualY = y;
      cursor.style.transform = `translate(${x}px, ${y}px)`;
    }
  }

  function showSnapRing(cx, cy) {
    ring.style.transition = 'none';
    ring.style.transform = `translate(${cx - 16}px, ${cy - 16}px) scale(0)`;
    ring.style.opacity = '1';

    // Force reflow
    ring.getBoundingClientRect();

    ring.style.transition = 'transform 0.45s cubic-bezier(0.34,1.56,0.64,1), opacity 0.5s ease';
    ring.style.transform = `translate(${cx - 16}px, ${cy - 16}px) scale(1)`;
    ring.style.opacity = '0';
  }

  // ── Event listeners ──────────────────────────────────────────────────────

  // Track real mouse to keep virtual cursor in sync when not snapping
  document.addEventListener('mousemove', (e) => {
    if (!enabled || isSnapping) return;
    virtualX = e.clientX;
    virtualY = e.clientY;
    cursor.style.transform = `translate(${virtualX}px, ${virtualY}px)`;
  }, true);

  // On click: snap virtual cursor to center
  document.addEventListener('click', (e) => {
    if (!enabled) return;

    const cx = window.innerWidth / 2;
    const cy = window.innerHeight / 2;

    showSnapRing(cx, cy);
    animateCursor(cx, cy, 380);
  }, true);

  // ── Message bridge (from popup) ──────────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'CURSORSNAP_SET') {
      if (msg.enabled) enable();
      else disable();
    }
    if (msg.type === 'CURSORSNAP_QUERY') {
      chrome.runtime.sendMessage({ type: 'CURSORSNAP_STATE', enabled });
    }
  });

  // ── Persist state via chrome.storage ────────────────────────────────────
  chrome.storage.local.get('cursorsnap_enabled', (result) => {
    if (result.cursorsnap_enabled === true) enable();
  });

  chrome.storage.onChanged.addListener((changes) => {
    if ('cursorsnap_enabled' in changes) {
      if (changes.cursorsnap_enabled.newValue === true) enable();
      else disable();
    }
  });

})();
