const toggle = document.getElementById('toggle');
const dot = document.getElementById('dot');
const statusText = document.getElementById('status-text');
const logo = document.getElementById('logo');

function applyState(enabled) {
  toggle.checked = enabled;
  dot.classList.toggle('active', enabled);
  logo.classList.toggle('active', enabled);
  statusText.textContent = enabled ? 'Active' : 'Disabled';
}

// Send message to the active tab's content script
function sendToTab(enabled) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;
    chrome.tabs.sendMessage(tabs[0].id, { type: 'CURSORSNAP_SET', enabled });
  });
}

// Read persisted state from storage
chrome.storage.local.get('cursorsnap_enabled', (result) => {
  const enabled = result.cursorsnap_enabled === true;
  applyState(enabled);
});

toggle.addEventListener('change', () => {
  const enabled = toggle.checked;
  applyState(enabled);
  chrome.storage.local.set({ cursorsnap_enabled: enabled });
  sendToTab(enabled);
});
